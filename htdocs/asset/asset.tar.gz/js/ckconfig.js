CKEDITOR.editorConfig = function( config ) {
  
};
